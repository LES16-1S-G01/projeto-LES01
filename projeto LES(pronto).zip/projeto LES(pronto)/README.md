# Angular Express Seed Example App

Based on the [Angular Express Seed](https://github.com/btford/angular-express-seed), this simple app illustrates how to use [AngularJS](http://angularjs.org/) and [Express](http://expressjs.com/) on a [Node.js](http://nodejs.org/) server to make a simple blog.


Alterado pelo prof. Antonio Sergio Bernardo na Faculdade de Tecnologia de Sorocaba - Fatec

para fins didáticos na disciplina Laboratório de Engenharia de Software - LES
