/*
 * Serve JSON to our AngularJS client
 */
// For a real app, you'd make database requests here.
// For this example, "data" acts like an in-memory "database"
var data = {
  "posts": [
    {
      "nome": "Jéssica Ferraz",
      "cpf": "235.822.498-99",
      "mensalidade" : "90",
      "idade" : "20",
      "text": "Girar feito um pião"
    },
    {
      "nome": "Pedro Augusto",
      "cpf": "144.982.262-72",
      "mensalidade" : "120",
      "idade" : "19",
      "text": "Ficar GIGANTE!!!"
    },
    {
      "nome": "João Vitor Neri",
      "cpf": "404.598.800-78",
      "mensalidade" : "60",
      "idade" : "20",
      "text": "Treinar loucamente"
    }
  ]
};

// GET

exports.posts = function (req, res) {
  var posts = [];
  data.posts.forEach(function (post, i) {
    posts.push({
      id: i,
      nome: post.nome,
      cpf: post.cpf,
      mensalidade: post.mensalidade,
      idade: post.idade,
      text: post.text.substr(0, 50) + '...'
    });
  });
  res.json({
    posts: posts
  });
};

exports.post = function (req, res) {
  var id = req.params.id;
  if (id >= 0 && id < data.posts.length) {
    res.json({
      post: data.posts[id]
    });
  } else {
    res.json(false);
  }
};

// POST

exports.postAdd = function (req, res) {
  data.posts.push(req.body);
  res.json(req.body);
};

// PUT

exports.postEdit = function (req, res) {
  var id = req.params.id;

  if (id >= 0 && id < data.posts.length) {
    data.posts[id] = req.body;
    res.json(true);
  } else {
    res.json(false);
  }
};

// DELETE

exports.postDelete = function (req, res) {
  var id = req.params.id;

  if (id >= 0 && id < data.posts.length) {
    data.posts.splice(id, 1);
    res.json(true);
  } else {
    res.json(false);
  }
};
